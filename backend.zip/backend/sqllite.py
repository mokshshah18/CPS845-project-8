import sqlite3

conn = sqlite3.connect('campus.db')